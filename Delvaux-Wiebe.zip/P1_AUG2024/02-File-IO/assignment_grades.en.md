# Question 2: Analyzing Student Preferences

You have a text file named `student_preferences.text` containing data on students preferences for extracurricular activities. Each row in the text file represents a student's preference and includes the following fields: StudentID, ActivityType and PreferenceScore.

In file `student.py` write a Python function `analyze_preferences(inputfile)` that:

- Reads the text file `inputfile` and extracts the students preference data.
- Determines the average preference score for each activity type. Rounded at 1 number after the comma.
- Writes the results to a file named `preference_analysis.txt` in a structured format.

# Example
## Input

```
StudentID,ActivityType,PreferenceScore
001,Sports,8
002,Music,7
003,Art,9
004,Drama,8
005,Science,7
006,Math,9
001,Music,6
002,Sports,9
003,Drama,6
004,Science,9
005,Math,8
006,Art,7
001,Drama,7
002,Art,8
003,Science,7
004,Math,6
005,Music,9
006,Sports,8
001,Science,9
002,Math,8
003,Music,6
004,Art,7
005,Drama,8
006,Science,9
```

## Needed output

```
Average Preference Score per Activity:
- Sports: 8.3
- Music: 7.0
- Art: 7.8
- Drama: 7.3
- Science: 8.2
- Math: 7.8
```

