# Vraag 2: Analyse van voorkeuren van studenten

Je hebt een tekstbestand genaamd `student_preferences.text` met daarin gegevens over de voorkeuren van studenten voor buitenschoolse activiteiten. Elke rij in het tekstbestand vertegenwoordigt de voorkeur van een student en bevat de volgende velden: StudentID, ActivityType and PreferenceScore.

Schrijf in het bestand `student.py` een Python-functie `analyze_preferences(inputfile)` die:

- Het tekstbestand `inputfile` leest en er de voorkeurgegevens van de studenten uithaalt.
- De gemiddelde "PreferenceScore" voor elk activiteitstype bepaalt, afgerond op 1 cijfer na de komma.
- De resultaten schrijft naar een bestand genaamd `preference_analysis.txt` in een gestructureerd formaat.

# Voorbeeld
## Input

```
StudentID,ActivityType,PreferenceScore
001,Sports,8
002,Music,7
003,Art,9
004,Drama,8
005,Science,7
006,Math,9
001,Music,6
002,Sports,9
003,Drama,6
004,Science,9
005,Math,8
006,Art,7
001,Drama,7
002,Art,8
003,Science,7
004,Math,6
005,Music,9
006,Sports,8
001,Science,9
002,Math,8
003,Music,6
004,Art,7
005,Drama,8
006,Science,9
```

## Gewenste output

```
Average Preference Score per Activity:
- Sports: 8.3
- Music: 7.0
- Art: 7.8
- Drama: 7.3
- Science: 8.2
- Math: 7.8
```

