# Write youre code here

def calculate_avg(by_preferenceScore):
    result = {}
    for activity in by_preferenceScore:
        s = sum(by_preferenceScore[activity])
        c = len(by_preferenceScore[activity])
        result[activity] = round(s/c,1)
    return result


def analyze_preferences(inputfile):
    with open(inputfile, 'r') as file:
        doc = file.readlines()

    by_preferenceScore = {}

    
    for line in doc:
        StudentID,ActivityType,PreferenceScore = line.split(",")
        PreferenceScore = int(PreferenceScore)
        if ActivityType not in by_preferenceScore:
            by_preferenceScore[ActivityType] = [PreferenceScore]
        else:
            by_preferenceScore[ActivityType].append(PreferenceScore)


    by_average_preferenceScore = calculate_avg(by_preferenceScore)

    with open('preference_analysis.txt', 'w', encoding='utf-8') as outFile:
        outFile.write(f"Average Preference Score per Activity:\n")
        for act,score in by_average_preferenceScore.items():
            outFile.write(f"- {act}: {score}\n")

analyze_preferences("student_preferences.txt")

