# Write youre code here

def find_second_largest(numbers):
    new_list = []
    idx = 0
    for value in range(len(numbers)):
        if numbers[value] not in new_list:
            new_list.append(numbers[value])
            idx = len(new_list)
        new_list.sort()
        # new_list.pop(1)
    if new_list[idx-2] == new_list[idx-1]:
        return None
    else:
        return new_list[idx-1]


print(find_second_largest([3, 7, 2, 8, 6, 5]))  # Output: 7
print(find_second_largest([1,4,4,5,1,6,6,7,7])) # Output: 6
print(find_second_largest([1])) # Output: None (as there's no second largest)
print(find_second_largest([1, 1, 1, 1]))       # Output: None (as there's no second 