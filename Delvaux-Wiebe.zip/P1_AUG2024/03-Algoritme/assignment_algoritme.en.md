# Question 3 : Find the second largest element

In file `student.py` write a Python function `find_second_largest(numbers)` that takes a list of integers `numbers` and returns the second largest element in the list.

## Example usage

```python
# Example usage
print(find_second_largest([3, 7, 2, 8, 6, 5]))  # Output: 7
print(find_second_largest([1,4,4,5,1,6,6,7,7])) # Output: 6
print(find_second_largest([1])) # Output: None (as there's no second largest)
print(find_second_largest([1, 1, 1, 1]))       # Output: None (as there's no second largest)
```
