# Vraag 3: Vind het op één na grootste element

Schrijf in het bestand `student.py` een Python-functie `find_second_largest(numbers)` die een lijst van gehele getallen `numbers` als parameter heeft en het op één na grootste element in de lijst teruggeeft.

## Voorbeeld

```python
# Example usage
print(find_second_largest([3, 7, 2, 8, 6, 5]))  # Output: 7
print(find_second_largest([1,4,4,5,1,6,6,7,7])) # Output: 6
print(find_second_largest([1])) # Output: None (as there's no second largest)
print(find_second_largest([1, 1, 1, 1]))       # Output: None (as there's no second largest)
```
