# Vraag 1: Spelers en Teams

* Plaats alle code voor deze oefening in het bestand `student.py`.
* In de opgave vermelden we bewust niet wanneer `self` moet gebruikt worden.
  Het is jouw verantwoordelijkheid om deze parameter toe te voegen wanneer nodig.
* Zorg ervoor dat namen precies zoals gespecificeerd worden gespeld, inclusief die van de parameters.
* Je hebt een bestand `basic_tests_sports.py` gekregen dat fundamentele tests bevat, zoals het verifiëren van het bestaan van bepaalde klassen en de juistheid van namen.
  *  Voer deze test uit via _rechtermuisklik - Open in Integrated Terminal_ met het commando:
    ```bash
    $ pytest basic_tests_sports.py
    ```
  * Een ontbrekende klasse zorgt ervoor dat tests die zich op die klasse richten, worden overgeslagen.
   Overgeslagen tests worden als mislukt beschouwd.
  * Deze tests voeren alleen oppervlakkige controles uit. 
   Mislukte of overgeslagen tests duiden erop dat je code onvolledig of onjuist is.
   Het slagen voor de tests garandeert echter niet dat je code volledig correct is! De functionaliteit van je code wordt namelijk niet gecontroleerd. 
  * Dit testbestand moet correct worden uitgevoerd om in aanmerking te komen voor punten.

## Klasse 'Player'
De klasse `Player` vertegenwoordigt individuele sportspelers.

* Definieer een klasse `Player`.
* Definieer de constructor van `Player`:
  * De constructor moet drie parameters accepteren: `name` (een string), `position` (een string) en `rating` (een geheel getal).
    * Typecontrole van de parameters is niet nodig.
  * Voorbeelden:
    *  `name` = "Lionel Messi"; `position` = "Aanvaller"; `rating` = 94
    *  `name` = "Cristiano Ronaldo"; `position` = "Aanvaller"; `rating` = 93
    *  `name` = "Kevin De Bruyne"; `position` = "Middenvelder"; `rating` = 91
* Sla `name` en `position` op als public fields.
* Sla `rating` op in een private field dat toegankelijk is via een property.
* Definieer een setter voor `rating`.
  * De rating van een speler moet tussen 0 en 100 liggen (0 en 100 inclusief). Als de rating buiten dit bereik valt, moet de setter een `ValueError` opwerpen.
* Definieer een methode `get_details()` die een stringrepresentatie van de speler teruggeeft, zoals weergegeven in het voorbeeld.
* Definieer een methode `compare_rating(other_player)` die de rating van de speler vergelijkt met de rating van een andere speler en **True** teruggeeft als de speler een hogere rating heeft dan `other_player`, anders **False**. De other_player is een object van de klasse `Player`.

## Klasse Team

De klasse `Team` vertegenwoordigt een sportteam.

* Definieer een klasse`Team`.
* Definieer de constructor van `Team`:
  * De constructor moet één parameter accepteren: `name` (een string).
  * Een `Team` moet ook een veld `roster` hebben, dat een lijst is van spelers binnen het team. Deze lijst is leeg bij het aanmaken van een `Team`.
* Sla `name` op als een public field.
* Sla `roster` op in een private field dat toegankelijk is via een property.
* Definieer een methode `add_player(player)` die een speler `player` toevoegt aan `roster`. De parameter `player` is een object van de klasse `Player`.
  * Een speler mag niet worden toegevoegd als er al een andere speler met dezelfde naam in het `roster` staat. Houd geen rekening met hoofdlettergevoeligheid bij het vergelijken van spelersnamen.
  * Als een speler al bestaat, werp dan een `ValueError` met het bericht `Player already exist!`
* Definieer een methode `remove_player(player_name)` die een speler verwijdert uit `roster` op basis van de opgegeven naam. Als er geen speler met de opgegeven naam bestaat, doe dan niets. Houd geen rekening met hoofdlettergevoeligheid bij het vergelijken van spelersnamen.
* Definieer een methode `find_players_by_position(position)` die een lijst teruggeeft van spelers die op een bepaalde positie spelen. Houd geen rekening met hoofdlettergevoeligheid bij het vergelijken van spelersposities.


## Voorbeeld

```python
>>> messi = Player("Lionel Messi", "Forward", 94)
>>> ronaldo = Player("Cristiano Ronaldo", "Forward", 93)
>>> de_bruyne = Player("Kevin De Bruyne", "Midfielder", 91)

>>> barcelona = Team("FC Barcelona")

>>> barcelona.add_player(messi)
>>> barcelona.add_player(ronaldo)
>>> barcelona.add_player(de_bruyne)

>>> barcelona.remove_player("Cristiano Ronaldo")

>>> for player in barcelona.roster:
      print(player.get_details())

>>> for player in barcelona.find_players_by_position("Forward"):
      print(player.get_details())

print(messi.compare_rating(ronaldo))

## output

Player: Kevin De Bruyne, Position: Midfielder, Rating: 91
Player: Lionel Messi, Position: Forward, Rating: 94
Player: Lionel Messi, Position: Forward, Rating: 94
True
```
