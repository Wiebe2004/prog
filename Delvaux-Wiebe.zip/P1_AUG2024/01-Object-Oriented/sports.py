# Write youre code here

class Player:
    def __init__(self, name,position,rating):
        self.name = name
        self.position = position
        self.__rating = rating

    
    @property
    def rating(self):
        return self.__rating
    
    @rating.setter
    def rating(self,rating):
        if not 0 <= rating <= 100:
            raise ValueError("Rating moet tussen 0 en 100 liggen (0,100 inclusief)")
    
    def get_details(self):
        return f"Player: {self.name}, Position: {self.position}, Rating: {self.__rating}"
    
    def compare_rating(self, other_player):
        return self.__rating > other_player.rating
        
class Team:
    def __init__(self, name):
        self.name = name
        self.__roster = list()

    @property
    def roster(self):
        return self.__roster
    
    def __findPlayerIndex(self, name):
        for p in range(len(self.__roster)):
            if self.__roster[p].name.lower() == name.lower():
                return p
        return -1
        
    def add_player(self,player):
        if self.__findPlayerIndex(player.name) < 0:
            self.__roster.append(player)
        else:
            raise ValueError(f"Player already exists!")
    
    def remove_player(self,player_name):
        idx = self.__findPlayerIndex(player_name)
        if idx >= 0:
            self.__roster.pop(idx)
    
    def find_players_by_position(self, position):
        player_by_pos = list()
        for p in range(len(self.__roster)):
            if self.__roster[p].position.lower() == position.lower():
                player_by_pos.append(self.__roster[p])
        return player_by_pos


messi = Player("Lionel Messi", "Forward", 94)
ronaldo = Player("Cristiano Ronaldo", "Forward", 93)
de_bruyne = Player("Kevin De Bruyne", "Midfielder", 91)

barcelona = Team("FC Barcelona")

barcelona.add_player(messi)
barcelona.add_player(ronaldo)
barcelona.add_player(de_bruyne)

barcelona.remove_player("Cristiano Ronaldo")

for player in barcelona.roster:
      print(player.get_details())

for player in barcelona.find_players_by_position("Forward"):
      print(player.get_details())

print(messi.compare_rating(ronaldo))