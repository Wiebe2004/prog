# Question 1: Players and Teams

* Place all code for this exercise in `student.py`.
* In these instructions, the omission of `self` is intentional.
  It is your responsibility to include this parameter where necessary.
* Ensure that names are spelled exactly as specified, including those of the parameters.
* You have been provided with a `basic_tests_sports.py` file that contains fundamental tests, such as verifying the existence of certain classes and the correctness of names.
  * Run these tests using the command:

    ```bash
    $ pytest basic_tests_sports.py
    ```

  * A missing class will cause tests focusing on that class to be skipped.
     Skipped tests are considered failed.
  * These tests only perform superficial checks.
     Failing or skipped tests indicate that your code is incomplete or incorrect.
     However, passing tests do not guarantee that your code is fully correct!
  * This test file must run correctly for you to earn credit.

## Class Player
The `Player` class represents individual sports players.

* Define a class `Player`.
* Define the `Player` constructor:
  * The constructor should accept three parameters: `name` (a string), `position` (a string), and `rating` (an integer).
    * Type checking of the parameters is not necessary.
  * Examples:
    * `name` = "Lionel Messi"; `position` = "Forward"; `rating` = 94
    * `name` = "Cristiano Ronaldo"; `position` = "Forward"; `rating` = 93
    * `name` = "Kevin De Bruyne"; `position` = "Midfielder"; `rating` = 91
* Store `name` and `position` as public fields.
* Store `rating` in a private field accessible via a property.
* Define a setter for `rating`.
  * A player's rating must be between 0 and 100 ( 0 and 100 inclusive). If the rating is out of this range, the setter should raise a `ValueError`.
* Define a method `get_details()` which returns a string representation of the player, as shown in the example usage.
* Define a method `compare_rating(other_player)` that compares the player's rating with another player's rating and returns **True** if the player has a higher rating then the other_player object, otherwise **False**. The other_player is a `Player` object.

## Class Team

The `Team` class represents a sports team.

* Define a class `Team`.
* Define the `Team` constructor:
  * The constructor should accept one parameter: `name` (a string).
  * A `Team` should also have a field `roster` which is a list of players within the team. This list is empty upon the creation of a `Team`.
* Store `name` as a public field.
* Store `roster` in a private field accessible via a property.
* Define a method `add_player(player)` that adds a `player` to `roster`. The `player` parameter is an `Player` object
  * A `player` should not be added if another `player` with the same name already exists in the roster. Ignore case sensitivity when comparing player names.
  * If a player already exist, the raise a `ValueError` with the message `Player already exist!`
* Define a method `remove_player(player_name)` that removes a `Player` from `roster` based on the provided name. If no `Player` with the specified name exists, do nothing. Ignore case sensitivity when comparing player names.
* Define a method `find_players_by_position(position)` that returns a list of players that play in a specified position.  Ignore case sensitivity when comparing player positions.

## Example usage

```python
>>> messi = Player("Lionel Messi", "Forward", 94)
>>> ronaldo = Player("Cristiano Ronaldo", "Forward", 93)
>>> de_bruyne = Player("Kevin De Bruyne", "Midfielder", 91)

>>> barcelona = Team("FC Barcelona")

>>> barcelona.add_player(messi)
>>> barcelona.add_player(ronaldo)
>>> barcelona.add_player(de_bruyne)

>>> barcelona.remove_player("Cristiano Ronaldo")

>>> for player in barcelona.roster:
      print(player.get_details())

>>> for player in barcelona.find_players_by_position("Forward"):
      print(player.get_details())

print(messi.compare_rating(ronaldo))

## output

Player: Kevin De Bruyne, Position: Midfielder, Rating: 91
Player: Lionel Messi, Position: Forward, Rating: 94
Player: Lionel Messi, Position: Forward, Rating: 94
True
```
