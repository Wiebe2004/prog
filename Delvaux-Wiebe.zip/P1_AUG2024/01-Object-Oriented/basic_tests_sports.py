import inspect
import pytest
import sports

def if_class_exists(class_name):
    return pytest.mark.skipif(class_name not in dir(sports), reason=f'Skipped because {class_name} has not been defined')

def has_property(cls, *, property_name):
    if not hasattr(cls, property_name):
        return False
    prop = getattr(cls, property_name)
    if type(prop) is not property:
        return False
    return True

def has_method(cls, *, method_name, parameter_names=None):
    if parameter_names is None:
        parameter_names = []
    method = getattr(cls, method_name)
    if not inspect.isfunction(method):
        return False
    specs = inspect.getfullargspec(method)
    if specs.args != parameter_names:
        return False
    return True

def test_class_Player_is_defined():
    assert 'Player' in dir(sports), 'Class Player has not been defined'

@if_class_exists('Player')
@pytest.mark.parametrize('kwargs', [
    {
        'method_name': '__init__',
        'parameter_names': ['self', 'name', 'position', 'rating']
    },
    {
        'method_name': 'get_details',
        'parameter_names': ['self'],
    },
    {
        'method_name': 'compare_rating',
        'parameter_names': ['self', 'other_player'],
    },
])
def test_Player_methods(kwargs):
    assert has_method(
        sports.Player,
        **kwargs), f"Player's method {kwargs['method_name']} is missing or incorrect."

@if_class_exists('Player')
@pytest.mark.parametrize("attr",['name', 'position', 'rating'])
def test_Player_attributes(attr):
    player = sports.Player("x",["x"],True)
    assert hasattr(player,attr), f"Players's attribute {attr} is missing or incorrect."


def test_class_Team_is_defined():
    assert 'Team' in dir(sports), 'Class Team has not been defined'

@if_class_exists('Team')
@pytest.mark.parametrize('kwargs', [
    {
        'method_name': '__init__',
        'parameter_names': ['self', 'name']
    },
    {
        'method_name': 'add_player',
        'parameter_names': ['self', 'player'],
    },
    {
        'method_name': 'remove_player',
        'parameter_names': ['self', 'player_name'],
    },
    {
        'method_name': 'find_players_by_position',
        'parameter_names': ['self', 'position'],
    },
])
def test_Team_methods(kwargs):
    assert has_method(
        sports.Team,
        **kwargs), f"Team's method {kwargs['method_name']} is missing or incorrect."

@if_class_exists('Team')
@pytest.mark.parametrize("attr",["name"])
def test_Team_attributes(attr):
    team = sports.Team("x")
    assert hasattr(team,attr), f"Teams's attribute {attr} is missing or incorrect."